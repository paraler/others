package CalTime;
import CalTime.all.Common;
public class Plane implements Common
{
    public double runTimer(double a,double b,double c)
    {
        return (a+b+c);
    }
}
