package CalTime.all;
public interface Common
{
    double runTimer(double a,double b,double c);
}
